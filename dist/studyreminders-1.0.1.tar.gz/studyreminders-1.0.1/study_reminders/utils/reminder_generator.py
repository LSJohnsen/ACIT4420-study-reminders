
# Generates a reminder for the specified student and their course
def generate_reminder(name, course):
    return f"Hi {name}, remember to review {course} materials before the deadline!"